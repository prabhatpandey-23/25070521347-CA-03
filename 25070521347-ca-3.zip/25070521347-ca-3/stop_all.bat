@echo off
title Threadora Fashion Store - Stop (25070521347-ca-3)
echo Stopping all Threadora services...
cd /d "%~dp0"
call pm2.cmd stop all
call pm2.cmd delete all
echo [OK] All Threadora services stopped.
pause
