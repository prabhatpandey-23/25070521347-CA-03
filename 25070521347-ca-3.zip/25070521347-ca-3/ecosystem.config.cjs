const path = require('path');

module.exports = {
  apps: [
    {
      name: 'mongodb-service',
      cwd: __dirname,
      script: 'start-mongo.js',
      autorestart: true,
      max_restarts: 15,
      restart_delay: 3000
    },
    {
      name: 'threadora-backend',
      cwd: path.join(__dirname, 'server'),
      script: 'server.js',
      autorestart: true,
      max_restarts: 15,
      restart_delay: 3000
    },
    {
      name: 'threadora-frontend',
      cwd: path.join(__dirname, 'client'),
      script: path.join(__dirname, 'client', 'node_modules', 'vite', 'bin', 'vite.js'),
      args: '--host',
      autorestart: true,
      max_restarts: 15,
      restart_delay: 3000
    }
  ]
};
