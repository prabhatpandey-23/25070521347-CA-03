const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 100 },
  description: { type: String, required: true, trim: true, maxlength: 500 },
  category: { type: String, required: true, enum: ['T-Shirts', 'Shirts', 'Hoodies', 'Jeans', 'Dresses', 'Accessories'] },
  price: { type: Number, required: true, min: 0 },
  image: { type: String, required: true },
  sizes: { type: [String], default: ['S', 'M', 'L', 'XL'] },
  colors: { type: [String], default: ['Black'] },
  stock: { type: Number, default: 10, min: 0 },
  featured: { type: Boolean, default: false }
}, { timestamps: true });

module.exports = mongoose.model('Product', productSchema);
