require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const Product = require('./models/Product');
const Order = require('./models/Order');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json({ limit: '1mb' }));

mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/threadora_fashion')
  .then(() => console.log(`MongoDB connected: ${mongoose.connection.name}`))
  .catch((err) => {
    console.error('MongoDB connection failed:', err.message);
    process.exit(1);
  });

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected' });
});

app.get('/api/products', async (req, res, next) => {
  try {
    const filter = {};
    if (req.query.category && req.query.category !== 'All') filter.category = req.query.category;
    if (req.query.search) {
      const safeSearch = String(req.query.search).slice(0, 80);
      filter.$or = [
        { name: { $regex: safeSearch, $options: 'i' } },
        { description: { $regex: safeSearch, $options: 'i' } },
        { category: { $regex: safeSearch, $options: 'i' } }
      ];
    }
    const products = await Product.find(filter).sort({ featured: -1, createdAt: -1 });
    res.json(products);
  } catch (err) { next(err); }
});

app.get('/api/products/:id', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: 'Invalid product ID.' });
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ message: 'Product not found.' });
    res.json(product);
  } catch (err) { next(err); }
});

app.post('/api/products', async (req, res, next) => {
  try {
    const { name, description, category, price, image, sizes, colors, stock, featured } = req.body;
    if (!name || !description || !category || price === undefined || !image) {
      return res.status(400).json({ message: 'Name, description, category, price, and image are required.' });
    }
    const product = await Product.create({ name, description, category, price: Number(price), image, sizes, colors, stock: stock ?? 10, featured: Boolean(featured) });
    res.status(201).json(product);
  } catch (err) { next(err); }
});

app.delete('/api/products/:id', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: 'Invalid product ID.' });
    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) return res.status(404).json({ message: 'Product not found.' });
    res.json({ message: 'Product deleted.', id: product._id });
  } catch (err) { next(err); }
});

app.post('/api/orders', async (req, res, next) => {
  try {
    const { customer, items } = req.body;
    const required = ['name', 'email', 'address', 'city', 'postalCode'];
    if (!customer || required.some((key) => !String(customer[key] || '').trim())) {
      return res.status(400).json({ message: 'Please complete all customer details.' });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customer.email)) {
      return res.status(400).json({ message: 'Please enter a valid email address.' });
    }
    if (!Array.isArray(items) || items.length === 0) return res.status(400).json({ message: 'Your cart is empty.' });

    const savedItems = [];
    for (const item of items) {
      if (!mongoose.isValidObjectId(item.productId)) return res.status(400).json({ message: 'A cart product is invalid. Refresh and try again.' });
      const product = await Product.findById(item.productId);
      if (!product) return res.status(400).json({ message: 'A product in your cart is no longer available.' });
      const quantity = Number(item.quantity);
      if (!Number.isInteger(quantity) || quantity < 1 || quantity > 20) return res.status(400).json({ message: 'Quantity must be between 1 and 20.' });
      const size = String(item.size || '');
      if (!product.sizes.includes(size)) return res.status(400).json({ message: `Selected size is unavailable for ${product.name}.` });
      savedItems.push({ product: product._id, name: product.name, image: product.image, price: product.price, size, quantity });
    }
    const total = Number(savedItems.reduce((sum, item) => sum + item.price * item.quantity, 0).toFixed(2));
    const order = await Order.create({ customer, items: savedItems, total });
    res.status(201).json({ message: 'Order placed successfully!', order });
  } catch (err) { next(err); }
});

app.get('/api/orders', async (req, res, next) => {
  try {
    const orders = await Order.find().sort({ createdAt: -1 }).limit(100);
    res.json(orders);
  } catch (err) { next(err); }
});

app.use((req, res) => res.status(404).json({ message: 'API route not found.' }));
app.use((err, req, res, next) => {
  console.error(err);
  if (err.name === 'ValidationError') return res.status(400).json({ message: err.message });
  if (err.name === 'CastError') return res.status(400).json({ message: 'Invalid data supplied.' });
  res.status(500).json({ message: 'Server error. Check the backend terminal.' });
});

app.listen(PORT, () => console.log(`THREADORA API running at http://localhost:${PORT}`));
