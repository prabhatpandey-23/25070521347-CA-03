require('dotenv').config();
const mongoose = require('mongoose');
const Product = require('../models/Product');

const products = [
  { name: 'Everyday Essential Tee', description: 'A heavyweight cotton tee with a relaxed fit for everyday comfort.', category: 'T-Shirts', price: 699, image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=85', sizes: ['S','M','L','XL'], colors: ['White','Black','Sand'], stock: 24, featured: true },
  { name: 'Studio Oversized Shirt', description: 'A clean, easy layer with a modern oversized silhouette.', category: 'Shirts', price: 1299, image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=900&q=85', sizes: ['S','M','L','XL'], colors: ['Blue','White'], stock: 14, featured: true },
  { name: 'Weekend Hoodie', description: 'Soft fleece inside, minimal branding outside. Your new weekend uniform.', category: 'Hoodies', price: 1799, image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=900&q=85', sizes: ['S','M','L','XL'], colors: ['Grey','Black','Olive'], stock: 18, featured: true },
  { name: 'Relaxed Straight Jeans', description: 'Classic denim with a relaxed straight leg and all-day comfort.', category: 'Jeans', price: 1599, image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=900&q=85', sizes: ['28','30','32','34','36'], colors: ['Indigo','Black'], stock: 12, featured: false },
  { name: 'Soft Knit Polo', description: 'A refined everyday polo made for easy smart-casual styling.', category: 'Shirts', price: 1099, image: 'https://images.unsplash.com/photo-1625910513413-5fc45e9b2b1c?auto=format&fit=crop&w=900&q=85', sizes: ['S','M','L','XL'], colors: ['Cream','Navy'], stock: 16, featured: false },
  { name: 'City Crossbody Bag', description: 'A compact carry-all for essentials, finished with adjustable straps.', category: 'Accessories', price: 899, image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=900&q=85', sizes: ['One Size'], colors: ['Black','Tan'], stock: 20, featured: false },
  { name: 'Everyday Midi Dress', description: 'An easy-to-style midi dress with a clean shape and soft drape.', category: 'Dresses', price: 1499, image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=900&q=85', sizes: ['XS','S','M','L'], colors: ['Black','Floral'], stock: 9, featured: true },
  { name: 'Graphic Street Tee', description: 'A statement graphic tee for a little personality in your rotation.', category: 'T-Shirts', price: 799, image: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=900&q=85', sizes: ['S','M','L','XL'], colors: ['White','Charcoal'], stock: 21, featured: false }
];

async function seed() {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/threadora_fashion');
    await Product.deleteMany({});
    await Product.insertMany(products);
    console.log(`Seeded ${products.length} THREADORA products into ${mongoose.connection.name}.`);
  } catch (error) {
    console.error('Seed failed:', error.message);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
}
seed();
