import { useEffect, useMemo, useState } from 'react';
import { Search, ShoppingBag, ArrowUpRight, Menu, X, Plus, Minus, Trash2, Check, Heart, PackagePlus, Sparkles } from 'lucide-react';
import { getProducts, addProduct, deleteProduct, createOrder } from './api';

const categories = ['All', 'T-Shirts', 'Shirts', 'Hoodies', 'Jeans', 'Dresses', 'Accessories'];
const money = (n) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);

function Storefront({ onLogout }) {
  const [products, setProducts] = useState([]);
  const [category, setCategory] = useState('All');
  const [search, setSearch] = useState('');
  const [cart, setCart] = useState([]);
  const [sizes, setSizes] = useState({});
  const [drawer, setDrawer] = useState(false);
  const [checkout, setCheckout] = useState(false);
  const [admin, setAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [form, setForm] = useState({ name: '', email: '', address: '', city: '', postalCode: '' });
  const [newProduct, setNewProduct] = useState({ name: '', description: '', category: 'T-Shirts', price: '', image: '', sizes: 'S, M, L, XL', colors: 'Black, White', stock: 10 });

  async function loadProducts() {
    try {
      setLoading(true);
      const data = await getProducts({ search, category });
      setProducts(data);
      setError('');
    } catch (e) {
      setError(`${e.message} Make sure the backend and MongoDB are running.`);
    } finally { setLoading(false); }
  }
  useEffect(() => { loadProducts(); }, [category, search]);

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const featured = useMemo(() => products.filter(p => p.featured).slice(0, 4), [products]);

  function addToCart(product) {
    const size = sizes[product._id] || product.sizes[0];
    setCart(current => {
      const match = current.find(item => item._id === product._id && item.size === size);
      if (match) return current.map(item => item === match ? { ...item, quantity: Math.min(item.quantity + 1, 20) } : item);
      return [...current, { ...product, size, quantity: 1 }];
    });
    setNotice(`${product.name} added to your bag`);
    setDrawer(true);
    setTimeout(() => setNotice(''), 2500);
  }
  function updateQty(id, size, delta) {
    setCart(current => current.map(item => item._id === id && item.size === size ? { ...item, quantity: item.quantity + delta } : item).filter(item => item.quantity > 0));
  }
  async function submitOrder(e) {
    e.preventDefault();
    try {
      const result = await createOrder({
        customer: form,
        items: cart.map(item => ({ productId: item._id, size: item.size, quantity: item.quantity }))
      });
      setCart([]);
      setCheckout(false);
      setDrawer(false);
      setForm({ name: '', email: '', address: '', city: '', postalCode: '' });
      setNotice(`Order placed! Order ID: ${result.order._id.slice(-8).toUpperCase()}`);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (e) { setError(e.message); }
  }
  async function submitProduct(e) {
    e.preventDefault();
    try {
      await addProduct({
        ...newProduct,
        price: Number(newProduct.price),
        stock: Number(newProduct.stock),
        sizes: newProduct.sizes.split(',').map(s => s.trim()).filter(Boolean),
        colors: newProduct.colors.split(',').map(s => s.trim()).filter(Boolean)
      });
      setNewProduct({ name: '', description: '', category: 'T-Shirts', price: '', image: '', sizes: 'S, M, L, XL', colors: 'Black, White', stock: 10 });
      setNotice('Product saved to MongoDB.');
      setAdmin(false);
      await loadProducts();
    } catch (e) { setError(e.message); }
  }
  async function removeProduct(id) {
    if (!window.confirm('Delete this product from the database?')) return;
    try { await deleteProduct(id); await loadProducts(); setNotice('Product deleted.'); }
    catch (e) { setError(e.message); }
  }

  return <div className="site-shell">
    <div className="announcement">THE NEW SEASON IS HERE <span>✳</span> FREE SHIPPING ON ORDERS OVER ₹1,999</div>
    <header className="header">
      <a className="logo" href="#home" aria-label="THREADORA home">THREADORA<span>.</span></a>
      <nav className="desktop-nav">
        <a href="#shop">Shop all</a><a href="#featured">Trending</a><a href="#story">Our story</a>
      </nav>
      <div className="header-actions">
        <button className="icon-button search-trigger" onClick={() => document.getElementById('product-search')?.focus()} aria-label="Search"><Search size={20}/></button>
        <button className="bag-button" onClick={() => setDrawer(true)}><ShoppingBag size={19}/><span>Bag</span><b>{cartCount}</b></button>
        <button className="logout-button" onClick={onLogout}>Log out</button>
        <button className="icon-button mobile-menu" onClick={() => setAdmin(!admin)} aria-label="Open product manager"><Menu size={21}/></button>
      </div>
    </header>

    <main>
      <section className="hero" id="home">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-line"></span> EVERYDAY, ELEVATED</div>
          <h1>Wear your<br/><em>own kind</em><br/>of confidence.</h1>
          <p>Considered essentials. Better fits. Pieces that feel like you — from first coffee to last call.</p>
          <a className="primary-button" href="#shop">Explore the collection <ArrowUpRight size={18}/></a>
          <div className="hero-foot"><div className="avatar-stack"><span>F</span><span>✳</span><span>+</span></div><span>Loved by 2,000+ style seekers</span></div>
        </div>
        <div className="hero-visual">
          <img src="https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=1400&q=90" alt="Friends exploring contemporary fashion" />
          <div className="hero-sticker"><span>GOOD<br/>CLOTHES.</span><span className="sticker-star">✳</span><small>GOOD MOOD.</small></div>
          <div className="hero-caption"><span>01 / NEW SEASON</span><span>Made for your everyday →</span></div>
        </div>
      </section>

      <section className="ticker" aria-label="Brand values"><div>GOOD FITS ONLY <span>✳</span> LESS BUT BETTER <span>✳</span> MADE TO MOVE <span>✳</span> GOOD FITS ONLY <span>✳</span> LESS BUT BETTER <span>✳</span></div></section>

      {notice && <div className="toast"><Check size={17}/>{notice}</div>}
      {error && <div className="error-banner"><span>{error}</span><button onClick={() => setError('')} aria-label="Dismiss error"><X size={16}/></button></div>}

      <section className="collection section-wrap" id="shop">
        <div className="section-heading">
          <div><div className="eyebrow">THE THREADORA EDIT</div><h2>Find your <em>everyday.</em></h2></div>
          <p>Good clothes are the ones you reach for<br className="desktop-only"/> again and again.</p>
        </div>
        <div className="shop-tools">
          <div className="category-list">{categories.map(c => <button key={c} onClick={() => setCategory(c)} className={category === c ? 'category active' : 'category'}>{c}</button>)}</div>
          <label className="search-box"><Search size={17}/><input id="product-search" value={search} onChange={e => setSearch(e.target.value)} placeholder="Find your fit..." /></label>
        </div>
        {loading ? <div className="loading-state">Curating your collection...</div> : products.length === 0 ? <div className="empty-state"><Sparkles size={24}/><h3>No pieces found</h3><p>Try a different search or category.</p><button className="text-button" onClick={() => {setSearch('');setCategory('All');}}>Clear filters ↗</button></div> :
          <div className="product-grid">{products.map((product, i) => <article className="product-card" key={product._id}>
            <div className="product-image-wrap"><img src={product.image} alt={product.name} loading="lazy" onError={e => {e.currentTarget.src='https://placehold.co/600x750/f0ede6/24251f?text=THREADORA+Wear';}}/>
              {product.featured && <span className="product-tag">THREADORA PICK</span>}
              <button className="quick-add" onClick={() => addToCart(product)} aria-label={`Add ${product.name} to bag`}><Plus size={20}/></button>
              <span className="product-number">0{i+1}</span>
            </div>
            <div className="product-info"><div><h3>{product.name}</h3><p>{product.category}</p></div><strong>{money(product.price)}</strong></div>
            <div className="product-bottom"><label className="size-select">Size <select value={sizes[product._id] || product.sizes[0]} onChange={e => setSizes({...sizes, [product._id]: e.target.value})}>{product.sizes.map(size => <option key={size}>{size}</option>)}</select></label><span className="stock-note">{product.stock > 0 ? `${product.stock} in stock` : 'Out of stock'}</span></div>
            {admin && <button className="delete-product" onClick={() => removeProduct(product._id)}><Trash2 size={14}/> Delete product</button>}
          </article>)}</div>}
      </section>

      <section className="feature-band" id="featured">
        <div className="feature-image"><img src="https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=1200&q=85" alt="Contemporary streetwear styling" /></div>
        <div className="feature-copy"><div className="eyebrow">STYLE WITHOUT THE NOISE</div><h2>Less fuss.<br/><em>More feeling.</em></h2><p>We believe your wardrobe should work as hard as you do. Versatile staples, thoughtful details, and fits that make getting dressed the easiest part of your day.</p><a href="#shop" className="text-button">Shop the edit <ArrowUpRight size={17}/></a><div className="feature-mark">F<span>✳</span></div></div>
      </section>

      <section className="values section-wrap" id="story">
        <div className="eyebrow">WHY THREADORA?</div><h2>Made for real life.<br/><em>Styled by you.</em></h2>
        <div className="value-grid"><div><span>01</span><h3>Comfort first</h3><p>Easy fits and wearable fabrics that keep up with your day.</p></div><div><span>02</span><h3>Repeat worthy</h3><p>Versatile pieces you can style a dozen different ways.</p></div><div><span>03</span><h3>Your own rules</h3><p>No fashion rules. Just personal style, at your pace.</p></div></div>
      </section>

      <section className="newsletter"><div><div className="eyebrow">A LITTLE SOMETHING EXTRA</div><h2>Good things look<br/><em>good on you.</em></h2></div><div className="newsletter-right"><p>Fresh drops, styling notes, and first dibs. Only the good stuff.</p><form onSubmit={e => {e.preventDefault();setNotice('You are on the THREADORA list!');e.currentTarget.reset();}}><input type="email" placeholder="Your email address" required/><button type="submit" aria-label="Subscribe"><ArrowUpRight/></button></form><small>By subscribing, you agree to receive THREADORA updates.</small></div></section>
    </main>

    <footer className="footer"><a className="logo" href="#home">THREADORA<span>.</span></a><p>Good clothes. Good mood. Good you.</p><div className="footer-links"><a href="#shop">Shop</a><a href="#story">About</a><button onClick={() => {setAdmin(!admin);document.getElementById('shop')?.scrollIntoView({behavior:'smooth'});}}>Product manager</button></div><small>© 2026 Threadora · Student full-stack project</small></footer>

    {admin && <div className="admin-panel"><div className="panel-heading"><div><span className="eyebrow">DATABASE TOOLS</span><h3>Product manager</h3></div><button className="icon-button" onClick={() => setAdmin(false)}><X/></button></div><p className="panel-note">Products added here are saved to MongoDB.</p><form className="admin-form" onSubmit={submitProduct}>
      <input placeholder="Product name" required value={newProduct.name} onChange={e => setNewProduct({...newProduct,name:e.target.value})}/>
      <textarea placeholder="Short description" required value={newProduct.description} onChange={e => setNewProduct({...newProduct,description:e.target.value})}/>
      <select value={newProduct.category} onChange={e => setNewProduct({...newProduct,category:e.target.value})}>{categories.filter(c=>c!=='All').map(c=><option key={c}>{c}</option>)}</select>
      <input type="number" min="0" placeholder="Price in ₹" required value={newProduct.price} onChange={e => setNewProduct({...newProduct,price:e.target.value})}/>
      <input type="url" placeholder="Image URL (https://...)" required value={newProduct.image} onChange={e => setNewProduct({...newProduct,image:e.target.value})}/>
      <input placeholder="Sizes, comma separated" value={newProduct.sizes} onChange={e => setNewProduct({...newProduct,sizes:e.target.value})}/>
      <input placeholder="Colors, comma separated" value={newProduct.colors} onChange={e => setNewProduct({...newProduct,colors:e.target.value})}/>
      <input type="number" min="0" placeholder="Stock quantity" value={newProduct.stock} onChange={e => setNewProduct({...newProduct,stock:e.target.value})}/>
      <button className="primary-button full-button" type="submit"><PackagePlus size={17}/> Save product to database</button>
    </form></div>}

    {drawer && <div className="overlay" onMouseDown={e => {if(e.target===e.currentTarget){setDrawer(false);setCheckout(false);}}}>
      <aside className="cart-drawer">
        <div className="drawer-heading"><div><span className="eyebrow">YOUR SELECTION</span><h2>{checkout ? 'Checkout' : `Your bag (${cartCount})`}</h2></div><button className="icon-button" onClick={() => {setDrawer(false);setCheckout(false);}} aria-label="Close bag"><X/></button></div>
        {!checkout ? <>
          <div className="cart-items">{cart.length===0 ? <div className="empty-cart"><ShoppingBag size={32}/><h3>Your bag is taking a break.</h3><p>Find something that feels like you.</p><button className="primary-button" onClick={() => setDrawer(false)}>Explore pieces <ArrowUpRight size={16}/></button></div> : cart.map(item=><div className="cart-item" key={`${item._id}-${item.size}`}><img src={item.image} alt={item.name}/><div className="cart-item-info"><h3>{item.name}</h3><p>Size: {item.size}</p><strong>{money(item.price)}</strong><div className="quantity-control"><button onClick={()=>updateQty(item._id,item.size,-1)} aria-label="Decrease quantity"><Minus size={13}/></button><span>{item.quantity}</span><button onClick={()=>updateQty(item._id,item.size,1)} aria-label="Increase quantity"><Plus size={13}/></button><button className="remove-item" onClick={()=>setCart(c=>c.filter(x=>!(x._id===item._id&&x.size===item.size)))} aria-label="Remove item"><Trash2 size={14}/></button></div></div></div>)}</div>
          {cart.length>0 && <div className="cart-summary"><div><span>Subtotal</span><strong>{money(total)}</strong></div><p>Shipping and taxes calculated at checkout.</p><button className="primary-button full-button" onClick={()=>setCheckout(true)}>Continue to checkout <ArrowUpRight size={17}/></button></div>}
        </> : <form className="checkout-form" onSubmit={submitOrder}><p className="checkout-intro">Almost yours. Add your delivery details to place your demo order.</p>{[['name','Full name','text'],['email','Email address','email'],['address','Street address','text'],['city','City','text'],['postalCode','PIN / postal code','text']].map(([key,placeholder,type])=><label key={key}>{placeholder}<input type={type} required value={form[key]} onChange={e=>setForm({...form,[key]:e.target.value})}/></label>)}<div className="checkout-total"><span>Order total</span><strong>{money(total)}</strong></div><button className="primary-button full-button" type="submit">Place demo order <ArrowUpRight size={17}/></button><button className="back-button" type="button" onClick={()=>setCheckout(false)}>← Back to bag</button><small>No payment is collected in this demo.</small></form>}
      </aside>
    </div>}
    <button className="floating-admin" onClick={() => setAdmin(!admin)} title="Manage products"><PackagePlus size={18}/><span>Manage</span></button>
  </div>;
}
export default App;


function LoginPage({ onLogin }) {
  const [mode, setMode] = useState('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState('');

  function submit(e) {
    e.preventDefault();
    if (!email.trim() || !password) {
      setMessage('Enter your email and password to continue.');
      return;
    }
    if (mode === 'register' && !name.trim()) {
      setMessage('Enter your name to create an account.');
      return;
    }
    // Academic demo authentication only: creates a frontend session, not a secure account.
    onLogin({ name: mode === 'register' ? name.trim() : (email.split('@')[0] || 'Fashion lover'), email: email.trim() });
  }

  return <main className="auth-page">
    <div className="auth-visual">
      <img src="https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=1400&q=90" alt="Friends exploring contemporary fashion"/>
      <a className="auth-logo" href="#login">THREADORA<span>.</span></a>
      <div className="auth-quote"><span className="eyebrow">EVERYDAY, ELEVATED</span><h1>Wear your<br/><em>own kind</em><br/>of confidence.</h1><p>Considered essentials. Better fits. Pieces that feel like you.</p></div>
      <div className="auth-image-caption">GOOD CLOTHES. GOOD MOOD. GOOD YOU.</div>
    </div>
    <div className="auth-form-side">
      <div className="auth-topline"><span>THREADORA WEAR</span><span>YOUR STYLE, YOUR RULES</span></div>
      <form className="auth-card" onSubmit={submit}>
        <div className="auth-symbol">✳</div>
        <div className="eyebrow">{mode === 'login' ? 'WELCOME BACK' : 'JOIN THE THREADORA CLUB'}</div>
        <h2>{mode === 'login' ? <>Good to see<br/>you <em>again.</em></> : <>Find your<br/><em>everyday.</em></>}</h2>
        <p className="auth-subtitle">{mode === 'login' ? 'Sign in to explore the collection and find your next favourite.' : 'Create your demo account and make room for a little more style.'}</p>
        {mode === 'register' && <label className="auth-label">Full name<input autoComplete="name" value={name} onChange={e=>setName(e.target.value)} placeholder="Your name" required/></label>}
        <label className="auth-label">Email address<input type="email" autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" required/></label>
        <label className="auth-label">Password<div className="password-wrap"><input type={showPassword ? 'text' : 'password'} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 6 characters" minLength={6} required/><button type="button" onClick={()=>setShowPassword(!showPassword)}>{showPassword ? 'Hide' : 'Show'}</button></div></label>
        {message && <p className="auth-message">{message}</p>}
        <button className="primary-button full-button auth-submit" type="submit">{mode === 'login' ? 'Sign in to THREADORA' : 'Create demo account'} <ArrowUpRight size={17}/></button>
        <div className="auth-switch">{mode === 'login' ? "New to THREADORA?" : 'Already have an account?'} <button type="button" onClick={()=>{setMode(mode === 'login' ? 'register' : 'login');setMessage('');}}>{mode === 'login' ? 'Create an account' : 'Sign in'}</button></div>
        <div className="auth-divider"><span></span>OR<span></span></div>
        <button className="guest-button" type="button" onClick={()=>onLogin({name:'Guest',email:'guest@threadora.demo'})}>Continue as guest <ArrowUpRight size={15}/></button>
        <small className="demo-note">Academic demo sign-in only. No password is sent to a server or saved.</small>
      </form>
      <div className="auth-footer"><span>© 2026 Threadora</span><span>Designed for everyday confidence</span></div>
    </div>
  </main>;
}

function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState('login');
  const [showAbout, setShowAbout] = useState(false);

  function login(profile) {
    setUser(profile);
    setPage('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  function logout() {
    setUser(null);
    setPage('login');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  if (!user) return <LoginPage onLogin={login} />;

  return <div className="authenticated-app">
    <div className="welcome-strip">SIGNED IN AS <strong>{user.name}</strong><span>DEMO ACCOUNT</span></div>
    <Storefront onLogout={logout} />
    {showAbout && <div className="page-overlay" onMouseDown={e=>{if(e.target===e.currentTarget)setShowAbout(false);}}><section className="info-page"><button className="info-close" onClick={()=>setShowAbout(false)}><X/></button><span className="eyebrow">OUR STORY</span><h2>Style for the<br/><em>everyday you.</em></h2><p>THREADORA is a student-built fashion store concept focused on wearable essentials, personal style, and a simpler shopping experience.</p><div className="info-page-grid"><div><strong>01</strong><h3>Comfort first</h3><p>Easy fits made for real life.</p></div><div><strong>02</strong><h3>Repeat worthy</h3><p>Versatile pieces you will reach for again.</p></div><div><strong>03</strong><h3>Your own rules</h3><p>Personal style, at your pace.</p></div></div></section></div>}
    <div className="page-nav">
      <button className={page==='home'?'selected':''} onClick={()=>{setPage('home');document.getElementById('home')?.scrollIntoView({behavior:'smooth'});}}>Home</button>
      <button className={page==='shop'?'selected':''} onClick={()=>{setPage('shop');document.getElementById('shop')?.scrollIntoView({behavior:'smooth'});}}>Shop</button>
      <button onClick={()=>setShowAbout(true)}>About</button>
      <button onClick={()=>{setPage('orders');alert('Orders are stored in MongoDB. Use GET /api/orders or the threadora_fashion.orders collection in Compass to review demo orders.');}}>Orders</button>
    </div>
  </div>;
}
