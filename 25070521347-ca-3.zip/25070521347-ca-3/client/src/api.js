async function request(path, options = {}) {
  const response = await fetch(path, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || 'Something went wrong.');
  return data;
}
export const getProducts = (params = {}) => {
  const query = new URLSearchParams();
  if (params.search) query.set('search', params.search);
  if (params.category && params.category !== 'All') query.set('category', params.category);
  return request(`/api/products${query.size ? `?${query}` : ''}`);
};
export const addProduct = (product) => request('/api/products', { method: 'POST', body: JSON.stringify(product) });
export const deleteProduct = (id) => request(`/api/products/${id}`, { method: 'DELETE' });
export const createOrder = (payload) => request('/api/orders', { method: 'POST', body: JSON.stringify(payload) });
