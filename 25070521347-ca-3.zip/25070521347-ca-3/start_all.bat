@echo off
title Threadora Fashion Store - Launcher (25070521347-ca-3)
echo ====================================================
echo        THREADORA FASHION STORE (CA-3)
echo ====================================================
echo.
echo Starting MongoDB, Backend API, and Frontend...
cd /d "%~dp0"
call pm2.cmd delete all >nul 2>&1
call pm2.cmd start ecosystem.config.cjs
call pm2.cmd save
echo.
echo ====================================================
echo Services Status:
call pm2.cmd list
echo.
echo [OK] Everything is running!
echo Frontend: http://localhost:5173/
echo Backend:  http://localhost:5000/
echo MongoDB:  mongodb://localhost:27017
echo ====================================================
echo Services will continue running in the background.
echo.
pause
