const net = require('net');
const { spawn } = require('child_process');

function checkMongoRunning() {
  const socket = new net.Socket();
  socket.setTimeout(2000);

  socket.on('connect', () => {
    console.log('MongoDB is already running on port 27017.');
    socket.destroy();
    setInterval(() => {
      const ping = new net.Socket();
      ping.setTimeout(2000);
      ping.on('connect', () => ping.destroy());
      ping.on('error', () => {
        ping.destroy();
        console.error('MongoDB stopped responding! Exiting monitor to trigger restart...');
        process.exit(1);
      });
      ping.connect(27017, '127.0.0.1');
    }, 15000);
  });

  socket.on('error', () => {
    socket.destroy();
    console.log('Starting MongoDB on port 27017...');
    const mongoProcess = spawn(
      'C:\\Program Files\\MongoDB\\Server\\9.0\\bin\\mongod.exe',
      ['--dbpath', 'C:\\Users\\lenovo\\.gemini\\antigravity\\scratch\\data\\db', '--port', '27017'],
      { stdio: 'inherit' }
    );
    mongoProcess.on('exit', (code) => {
      console.log(`MongoDB exited with code ${code}`);
      process.exit(code || 0);
    });
  });

  socket.on('timeout', () => {
    socket.destroy();
    socket.emit('error');
  });

  socket.connect(27017, '127.0.0.1');
}

checkMongoRunning();
